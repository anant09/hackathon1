from django.apps import AppConfig


class ViewbookConfig(AppConfig):
    name = 'viewbook'
