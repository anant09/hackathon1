from django.apps import AppConfig


class Step2Config(AppConfig):
    name = 'step2'
